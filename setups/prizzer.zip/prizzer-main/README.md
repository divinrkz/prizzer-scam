# backdoor-scam
A purposeful scamming program to backdoor a client PC.
